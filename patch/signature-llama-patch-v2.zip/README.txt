Signature Llama — complete reproducible release package (SIGLLAMA-V2 current, SIGLLAMA-V1 preserved)
Independent model by Justin Addam Higgins. Not affiliated with Meta.

WHAT IS WHERE
  engine/            pinned v2 engine (sigllama.js) + vocab2.json
  weights/           sigllama-v2.bin — the current trained weights
  v1/                preserved v1 engine + vocab + weights (never changes)
  src/               original training/inference sources (v1-era, preserved)
  data/              llm-dictionary.json (+ .csv), explainer-kb.json, tool-libraries.json
  llama-api.js       on-demand ask API (SignatureLlama.ask / askWithProvenance)
  industry-llama.js  cloud client for "Llama · Industry Standard" (NOT the on-device model)
  sigllama.d.ts      TypeScript definitions for the engine + site APIs
  llama-manifest.json    canonical machine-readable entry point (manifest 2.0)
  llama-model-card.json  machine-readable model card (SIGLLAMA-V2 + SIGLLAMA-V1)
  manifests/llama-manifest-v1.json  the preserved v1 manifest
  model-status.json  single authoritative live model state
  llms.txt           plain-words summary for AI readers
  MANIFEST.json      every file in this ZIP with its SHA-256 (verify against it)

VERIFY
  sha256sum -c <(grep -v '^#' /dev/null)  # or compare each file's hash to MANIFEST.json
  The v2 weights hash must be e351a9e1133a1774782d9f6f0e77f6ab756ca769af59fbbe763f6321e32d7049
  and the v2 engine hash d387c26e4531838fbf07b860804bd27e01a6e4688f4675a33ba32108155d2bf1.

QUICK START
  See patch/embed-snippet.html, or the Developers section on the site.

LICENSE
  Free for any website, app, or project. No API key, no fee.
