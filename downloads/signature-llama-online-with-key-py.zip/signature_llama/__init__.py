"""Signature Llama (Online with Key) -- conversational on-device AI."""
from .engine import Llama, VARIANTS  # noqa
