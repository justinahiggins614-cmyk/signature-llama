# Signature Llama -- Online with Key (Python)

Your own API key, your provider. The key is stored device-local only and never leaves your device except to the provider you chose.

## Run it
    python3 -m signature_llama.chat
or
    python3 chat.py

## What is inside
- `signature_llama/guide.py` -- the conversational engine (zero-network,
  plain-words replies, full duties coverage, all 31 JAH network sites)
- `signature_llama/engine.py` -- the variant runtime (online behaviors,
  key handling, feature toggles, updater)
- `signature_llama/ecosystem.json` -- the 31-site knowledge base
- `chat.py` -- the chat entry point

## The four versions
- Offline Static -- no network, ever. The best version.
- Online, No Key Needed -- built-in free route (live knowledge refresh),
  falls back to the offline engine when offline.
- Online with Key -- your own provider key, stored device-local only
  (`~/.sigllama_key`, mode 600, or the SIGLLAMA_API_KEY env var).
- Best Figurehead -- every feature toggleable; `/check-updates` asks the
  live site whether a newer best version exists.

Independent project by Justin Addam Higgins. Not affiliated with Meta.
No .exe is offered -- it cannot be built on this machine.
