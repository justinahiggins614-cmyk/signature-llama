from setuptools import setup, find_packages
setup(name='signature-llama-online-with-key', version='2.1.0',
      description='Signature Llama (Online with Key) -- conversational on-device AI',
      packages=find_packages(), package_data={'signature_llama': ['ecosystem.json']},
      python_requires='>=3.8')
