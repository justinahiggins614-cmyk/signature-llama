from setuptools import setup, find_packages
setup(name='signature-llama-offline-static', version='2.0.0',
      description='Signature Llama (Offline Static) -- conversational on-device AI',
      packages=find_packages(), package_data={'signature_llama': ['ecosystem.json']},
      python_requires='>=3.8')
