"""Signature Llama (Offline Static) -- conversational on-device AI."""
from .engine import Llama, VARIANTS  # noqa
