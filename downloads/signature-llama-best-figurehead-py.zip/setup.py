from setuptools import setup, find_packages
setup(name='signature-llama-best-figurehead', version='2.1.0',
      description='Signature Llama (Best Figurehead) -- conversational on-device AI',
      packages=find_packages(), package_data={'signature_llama': ['ecosystem.json']},
      python_requires='>=3.8')
